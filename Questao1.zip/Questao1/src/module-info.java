module Questao1 {
	requires java.desktop;
}