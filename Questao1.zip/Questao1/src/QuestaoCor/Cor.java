package QuestaoCor;
import java.util.Scanner;

public class Cor {

	public static void main(String[] args) {

		Scanner ler = new Scanner(System.in);
		int [] vet = new int [10];
		int cor = 0;
		double soma=0;
		

		for(int i = 0; i<vet.length; i++) {
			
			System.out.printf("#%d Insira sua cor: ", i+1);
			cor = ler.nextInt();
			vet[i]=cor;
			soma = soma + cor;
		}
		
		if
		
		
		




		
	}

}
