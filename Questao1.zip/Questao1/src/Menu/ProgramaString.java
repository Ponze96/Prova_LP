package Menu;
import java.util.Random;
import java.util.Scanner;

public class ProgramaString {
	
	String numFrase, numPalavras, numeroVogais, numeroConsoantes;
	Scanner scan = new Scanner(System.in);
	
	do {	
		System.out.println("Digita a frase");
		System.out.println("1 - Numero de frases");
		System.out.println("2 - Numero de palavras");
		System.out.println("3 - Numero de vogais");
		System.out.println("4 - Numero de consoantes");
		System.out.println("5 - Sair");

		Scanner scan = new Scanner (System.in);
		int opcao = scan.nextInt();
		
		
		
		

	}
	
}